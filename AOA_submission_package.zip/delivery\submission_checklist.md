# Submission checklist

## Scientific content

- [x] Title does not claim multimodal fraud detection.
- [x] Image experiment is absent from the main manuscript.
- [x] Model-family comparison uses no imbalance treatment for every model.
- [x] Imbalance strategies are evaluated separately on one fixed model family.
- [x] AgeOfPolicyHolder sensitivity analysis is reported.
- [x] Expected-cost assumptions are labelled illustrative, not observed losses.
- [x] Investigation-capacity results cover 5%, 10%, 20%, and 30%.
- [x] Coverage-risk, ablation, calibration, and temporal analyses are reported.
- [x] All performance and region estimates include uncertainty where appropriate.
- [x] Fairness covers approval, abstention, and investigation actions.

## Files

- [x] Anonymous manuscript contains no author name, affiliation, ORCID, or identifying acknowledgements.
- [x] Separate title page contains the standardised author name: Adebayo Adetola Aliu.
- [x] Cover letter names Applied Operations and Analytics.
- [x] Figures and tables are embedded in the review manuscript.
- [x] Supplementary analysis notebook and machine-readable tables are included.
- [ ] GitHub URL is exact and a fixed release URL/DOI is inserted when available.

## Declarations

- [ ] Funding statement checked.
- [ ] Competing-interest statement checked.
- [ ] Data-availability statement checked.
- [ ] Code-availability statement checked.
- [x] AI-assistance statement accurately describes coding and language support.
- [ ] Dataset licences and reuse conditions checked.

## Zero-cost confirmation

- [ ] Re-open the official journal page on submission day.
- [ ] Capture the current statement that Taylor & Francis is covering publication charges.
- [ ] Confirm the submission system shows a zero author charge.
- [ ] If any APC is displayed, pause and obtain written confirmation before submitting.
