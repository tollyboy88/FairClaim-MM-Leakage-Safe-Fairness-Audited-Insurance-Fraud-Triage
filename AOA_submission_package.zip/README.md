# Applied Operations and Analytics revision package

## Paper identity

**Title:** Calibrated Selective Prediction for Leakage-Safe and
Fairness-Audited Motor Insurance Fraud Triage

**Target journal:** Applied Operations and Analytics

The main claim is operational selective triage using structured claim data.
The unlinked image experiment is not part of this manuscript.

## Revision map

| Desk-review concern | Implemented response |
|---|---|
| Multimodal claim overstated | Removed from title, research questions, principal results and conclusion |
| Age proxy retained | Added retain-versus-exclude `AgeOfPolicyHolder` sensitivity |
| Inconsistent model comparison | All model families first compared without weighting; imbalance tested separately |
| No operational value | Added fixed-capacity fraud capture and three illustrative cost scenarios |
| Weak abstention evaluation | Added binary/selective ablations and a coverage-risk curve |
| Binary-only fairness | Added approval, abstention and investigation rates plus group NPV/calibration |
| Limited uncertainty | Added bootstrap intervals, threshold stability, repeated seeds and temporal validation |
| Reproducibility gaps | Added MIT licence, `CITATION.cff` and GitHub Actions workflow |

## Reproduce

```powershell
python -m pip install -r requirements.txt
python scripts\run_aoa_revision_analyses.py
python scripts\finalize_aoa_outputs.py
python scripts\build_aoa_revision_notebook.py
python scripts\build_aoa_submission_docx.py
```

## Scientific boundary

Monetary values are scenario assumptions because the benchmark contains no
claim amount, recovery, investigator-time or payment-delay outcomes. They
measure policy sensitivity and must not be described as realised savings.
Temporal validation uses 1994 for training, 1995 for threshold selection and
1996 for testing; it is not external validation.
