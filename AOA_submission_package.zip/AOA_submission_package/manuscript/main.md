# Abstract
Motor insurance fraud screening is an allocation problem in which missed fraud, unnecessary investigation, and delayed legitimate payment have different operational consequences. This study evaluates a leakage-safe information-system artifact that converts calibrated fraud risk into approval, defer, and investigation actions. Using 15,420 public claims with 5.99% labelled fraud, six model families were compared without class weighting or resampling, followed by five imbalance treatments for the selected family. HistGradientBoosting without balancing achieved the highest mean cross-validated precision-recall area under the curve. Sigmoid calibration produced held-out PR-AUC 0.256 (95% bootstrap CI 0.204-0.317) and Brier score 0.050. At 10% investigation capacity, the model captured 40.5% of labelled fraud with 24.3% precision. Removing AgeOfPolicyHolder reduced test PR-AUC by approximately 4.0% and increased the age-band investigation-rate gap by approximately 9.4%. Chronological evaluation produced PR-AUC 0.158, materially below the random-split estimate. Validation-bootstrap threshold variation propagated to approval NPV, fraud capture, investigation precision, and defer coverage. The study contributes bounded design propositions for calibrated work allocation, comparable model evaluation, and adaptive fairness governance. Cost results remain illustrative and the artifact does not make autonomous claim decisions.

**Keywords:** insurance fraud; information systems design; three-way triage; human deferral; probability calibration; algorithmic fairness; investigation capacity; explainable artificial intelligence

# 1 Introduction
Insurance fraud detection is commonly treated as rare-event classification, but an insurer must allocate limited investigative attention while controlling missed fraud, unnecessary scrutiny, and delayed settlement. Reviews by Bolton and Hand (2002), Phua et al. (2010), Ngai et al. (2011), and West and Bhattacharya (2016) establish the statistical and data-mining foundations of fraud detection. The motor-insurance review by Schrijver et al. (2024) nevertheless shows continued reliance on scarce public datasets and supervised learning.

An operational fraud-screening system is more than a classifier. It is an information-system artifact that distributes work between a model and human decision makers. Its design must specify how scores are calibrated, how capacity constrains referrals, which cases require additional evidence, how explanations support professional judgment, and how subgroup outcomes are monitored. Information-systems scholarship treats artificial intelligence as involving interdependent choices about autonomy, learning, and inscrutability (Berente et al., 2021). Delegation research further distinguishes the allocation of tasks to and from agentic artifacts (Baird and Maruping, 2021), while experimental evidence shows that productive human-AI collaboration depends on who delegates and on the decision maker's ability to recognise comparative strengths (Fügener et al., 2022).

Fairness must also be designed as an ongoing sociotechnical capability rather than certified by one metric. Teodorescu et al. (2021) argue that fairness in automation requires richer forms of human-machine-learning augmentation. Tanriverdi and Akinyemi (2025) connect algorithmic injustice to interacting data, ecosystem, and model complexities. Rai, Tian, and Xue (2026) formalise fairness adaptation across representation, learning, and calibration layers, with human actors retaining responsibility for objectives, trade-offs, and contextual judgment. These perspectives motivate an artifact that exposes rather than hides the operational consequences of model, threshold, and governance choices.

The study follows the design-science principle that an artifact should be evaluated against a relevant problem and made inspectable to both research and practice (Hevner et al., 2004). Its contribution is a situated evaluation and a set of bounded design propositions, not a claim of a complete or universally validated design theory (Gregor and Hevner, 2013). Two research questions organise the study:

1. **RQ1:** How should an AI-enabled insurance fraud triage system combine calibrated risk, investigator capacity, and human deferral when allocating claims among approval, defer, and investigation actions?
2. **RQ2:** Which design and governance controls make that allocation auditable under class imbalance, proxy-sensitive fairness concerns, threshold uncertainty, and temporal shift?

The paper excludes the earlier image experiment from its contribution. The available image records are not linked at claim level to verified fraud labels, so damage-classification performance cannot establish fraud-prediction validity.

# 2 Theoretical background and research gap
## 2.1 Fraud screening as operational work allocation
Applied fraud studies often address imbalance through resampling or classifier-specific weighting. Examples include Subudhi and Panigrahi (2018), Harjai et al. (2019), Itri et al. (2019), Muranda et al. (2020; 2021), Komsrimorakot and Siriborvornratanakul (2025), and Ozaltin and Karadag Erdemir (2025). These studies advance prediction, but model-family effects become difficult to separate from imbalance treatment when candidate models use different class weights or when resampling crosses evaluation boundaries. SMOTE is influential (Chawla et al., 2002), but the value of any imbalance remedy remains an empirical question (He and Garcia, 2009).

Precision-recall evaluation is informative when the positive class is rare (Davis and Goadrich, 2006; Saito and Rehmsmeier, 2015). A higher PR-AUC, however, does not specify how many claims can be investigated, whether a nominal risk score behaves as a probability, or how intermediate-risk claims should be handled. Brier score evaluates probabilistic accuracy (Brier, 1950), and post-hoc calibration can change the meaning of an operating threshold (Niculescu-Mizil and Caruana, 2005; Guo et al., 2017). Cost-sensitive fraud research links asymmetric losses and temporal information to modelling decisions (Shi et al., 2023), but public motor-insurance studies rarely combine calibrated probabilities, fixed capacity, human deferral, and declared cost assumptions.

The proposed middle region is therefore defined as an intermediate-risk defer region. Its boundaries are operational: the lower threshold targets approval-region negative predictive value and the upper threshold maximises validation F2. It is not defined by predictive entropy, ensemble variance, or another direct uncertainty estimate. The study consequently does not claim that deferred observations are the most epistemically uncertain cases and does not present the method as selective prediction.

## 2.2 Fairness explanation and information systems design
Insurance fairness is domain-specific. Barry and Charpentier (2022) distinguish social and actuarial conceptions of fairness. Lindholm et al. (2024) show why proxy discrimination and demographic disparity should not be conflated, while Côté et al. (2025) demonstrate the role of causal reasoning in insurance fairness. Formal criteria can also conflict when group base rates differ (Hardt et al., 2016; Chouldechova, 2017; Kleinberg et al., 2017). The present study therefore reports descriptive subgroup outcomes and interval estimates. It does not infer discrimination from an action-rate gap or claim that deleting protected fields makes a system fair.

The information-systems perspective changes the unit of analysis from a model to a governed decision pipeline. Rai, Tian, and Xue (2026) locate fairness tensions across representation, learning, and calibration choices. This study operationalises those layers through protected-field separation and proxy sensitivity at representation, controlled model and imbalance experiments at learning, and calibrated three-action thresholds with subgroup monitoring at the decision layer. Human reviewers remain responsible for evidence assessment and final adjudication, consistent with delegation and augmentation research (Baird and Maruping, 2021; Teodorescu et al., 2021).

Explanation is treated as support for interrogation, not proof of causality. Local surrogates (Ribeiro et al., 2016) and additive attribution methods (Lundberg and Lee, 2017) are widely used, but correlated features can destabilise importance estimates (Fisher et al., 2019). The artifact uses held-out permutation importance as a global sensitivity measure and reference-replacement deltas for individual dashboard records. This restrained interpretation follows calls for explanations that help users understand and question AI outputs (Rai, 2020) and the practical categories in the Information Commissioner's Office and Alan Turing Institute (2020) guidance.

The research gap is an evaluated information-system artifact that connects comparable model development to calibrated work allocation, capacity, proxy-sensitive fairness, threshold uncertainty, temporal stress, and human accountability. The empirical analysis tests that artifact and supplies evidence for design propositions whose boundary conditions are stated explicitly.

# 3 Materials and methods
## 3.1 Data outcome and leakage controls
The Fraud Oracle benchmark contains 15,420 motor claims, of which 923 are labelled fraudulent (5.99%). The persistent dataset record is provided by Ibrahim (2024). The records cover 1994-1996. A stratified 60/20/20 split created training, validation, and untouched test partitions. PolicyNumber was removed as an identifier. Sex, Age, and MaritalStatus were withheld from scoring and retained for post-hoc audit. AgeOfPolicyHolder was initially retained as a categorical policyholder-age feature and then removed in the proxy sensitivity experiment.

Numeric missing values were median-imputed and standardised. Categorical values were most-frequent-imputed and one-hot encoded. Every learned preprocessing operation and every resampling operation was fitted within the relevant training fold. Validation data selected the model, calibration method, and decision thresholds. The test set was not used for those selections.

## 3.2 Model family and imbalance experiments
Six model families were first compared without class weighting or resampling: a prior-probability dummy classifier, logistic regression, Gaussian naive Bayes, random forest, Extra Trees, and HistGradientBoosting. Mean five-fold stratified training PR-AUC was the primary family-selection criterion. PR-AUC on the fixed validation partition served as a confirmation check.

The selected family was then evaluated under no balancing, balanced class weights, random oversampling, random undersampling, and SMOTENC. Sampling occurred inside training folds. This two-stage design prevents model-family rankings from being confounded with different imbalance treatments. PR-AUC is the primary metric; ROC-AUC and Brier score are secondary metrics. For precision P and recall R, the F2 score is:

$$F_2=\frac{5PR}{4P+R},\qquad P=\frac{TP}{TP+FP},\qquad R=\frac{TP}{TP+FN}.$$

{{TABLE:table_01_model_family_no_balancing.csv|Table 1 Model family comparison without balancing|model,imbalance_treatment,cv_pr_auc_mean,cv_pr_auc_sd,validation_pr_auc,validation_brier}}

{{TABLE:table_02_hgb_imbalance_strategies.csv|Table 2 Imbalance strategies evaluated for HistGradientBoosting|imbalance_strategy,cv_pr_auc_mean,cv_pr_auc_sd,validation_pr_auc,validation_brier,resampling_scope}}

{{FIGURE:figure_01_consistent_model_comparison.png|Figure 1 Validation PR-AUC for model-family and imbalance-strategy experiments}}

## 3.3 Calibration and three action policy
Five stratified training folds each fitted a HistGradientBoosting estimator. A held-out sigmoid calibrator mapped raw score z_k(x) to calibrated fraud probability p_k(x), and the ensemble mean formed the operational score:

$$p_k(x)=\frac{1}{1+\exp\{a_k z_k(x)+b_k\}},\qquad \hat p(x)=\frac{1}{5}\sum_{k=1}^{5}p_k(x).$$

The subscript k indexes the fold member, and the space between a_k and z_k(x) denotes multiplication. The positive sign in the denominator follows the fitted sigmoid parameterisation. Sigmoid and isotonic calibration were compared by validation Brier score; test Brier score was reported only after selection.

The investigation threshold tau_I maximised validation F2. The approval threshold tau_A was the largest lower threshold satisfying validation negative predictive value of at least 0.99:

$$\operatorname{NPV}=\frac{TN}{TN+FN},\qquad d(x)=\begin{cases}\text{approve},&\hat p(x)<\tau_A,\\ \text{defer},&\tau_A\leq\hat p(x)<\tau_I,\\ \text{investigate},&\hat p(x)\geq\tau_I.\end{cases}$$

The fitted thresholds were frozen before test evaluation. Defer means additional evidence or human review. Investigation is a referral signal rather than an accusation. Approval means normal processing rather than an irreversible automated payment decision.

## 3.4 Capacity and cost comparison
Claims were ranked by calibrated risk. The top 5%, 10%, 20%, and 30% were treated as fixed investigator-capacity budgets. At capacity q, fraud capture is the fraction of all labelled fraud within the highest-risk qN claims, while investigation precision is the fraud fraction among reviewed claims.

Three declared GBP scenarios were used: low cost (£100 investigation, £50 additional legitimate-claim burden, £5,000 missed fraud, £40 defer delay); base (£250, £150, £10,000, £100); and high loss (£500, £300, £25,000, £250). If N_I is the number investigated, N_I0 legitimate investigations, N_A1 approved fraud, N_D1 deferred fraud, and N_D0 legitimate deferrals, total scenario cost is:

$$C=c_I N_I+c_L N_{I0}+c_F(N_{A1}+\rho N_{D1})+c_D N_{D0},\qquad \rho=0.25.$$

The binary and three-way policies used the same investigation threshold tau_I and therefore referred exactly the same 830 test claims for investigation. The binary policy approved every remaining claim. The three-way policy deferred the intermediate band between tau_A and tau_I. The factor rho assumes that manual review recovers 75% of the missed-fraud consequence among deferred fraud cases. It is a sensitivity parameter, not an empirical estimate. Reported costs are not realised savings.

## 3.5 Proxy sensitivity fairness and explanation
The primary feature set retained AgeOfPolicyHolder while excluding the direct Age audit field. A second complete calibration-and-threshold pipeline removed AgeOfPolicyHolder. The specifications were compared on validation and test PR-AUC, ROC-AUC, Brier score, approval-region NPV, thresholds, and the maximum-minus-minimum age-band investigation rate.

For Sex, AgeBand, MaritalStatus, and Sex-by-AgeBand intersections, the audit reports prevalence, approval rate, defer rate, investigation rate, fraud missed in approval, approval-region NPV, mean score, expected calibration error, investigation true-positive rate, and investigation false-negative rate. Wilson 95% intervals accompany binomial rates. Five hundred test-set bootstraps estimate percentile intervals for between-group max-minus-min gaps. Results with few fraud-positive observations are treated as imprecise descriptive evidence.

Global explanation is the held-out PR-AUC reduction after feature j is permuted:

$$I_j=\operatorname{PR\!-!AUC}(f,X,y)-\operatorname{PR\!-!AUC}(f,X_{\pi(j)},y).$$

The dashboard's local explanation replaces one feature at a time with a documented reference value and reports the probability change. Neither method identifies a causal effect or independently justifies adverse action.

## 3.6 Robustness and threshold propagation
Five policy configurations were evaluated: uncalibrated binary prediction, calibrated binary prediction, uncalibrated three-way defer, calibrated three-way defer without a fairness-audit component, and the complete framework. Coverage is the share receiving approval or investigation, and covered-case error is classification error among those cases. A separate confidence-margin diagnostic ranks observations by distance from the binary F2 threshold; it is not used to define the operational defer region.

One thousand non-parametric test bootstraps estimated 95% intervals for PR-AUC, ROC-AUC, Brier score, precision, recall, and F2. Five hundred validation bootstraps reselected tau_A and tau_I. Each threshold pair was then applied to the same untouched test probabilities to record approval NPV, approval coverage, defer coverage, investigation coverage, fraud capture, and investigation precision. These ranges quantify propagation of threshold-selection instability; they are not a second bootstrap of the test population. The experiment was repeated under five split seeds. A chronological stress test trained on 1994, selected thresholds on 1995, and tested on 1996, with Year removed from predictors. This is an internal temporal stress test rather than external validation.

# 4 Results
## 4.1 Model selection and calibrated policy
HistGradientBoosting ranked first without balancing on the prespecified family-selection criterion, with mean five-fold training PR-AUC 0.251 (SD 0.030) and validation PR-AUC 0.244. Random forest had lower mean cross-validated PR-AUC (0.241) but a fixed-validation PR-AUC only 0.000064 higher. In the separate imbalance experiment, no balancing ranked first with validation PR-AUC 0.244. The result supports HistGradientBoosting with no balancing for this benchmark; it does not generalise to a claim that balancing is always ineffective.

The sigmoid-calibrated model achieved test PR-AUC 0.256 (95% bootstrap CI 0.204-0.317), ROC-AUC 0.843, Brier score 0.050, precision 0.166, and recall 0.746. The approval threshold was 0.046961 and the investigation threshold was 0.092956. The approval, defer, and investigation regions contained 1,785, 469, and 830 claims, with fraud rates 0.7%, 7.2%, and 16.6%. Approval-region NPV was 99.27%.

{{TABLE:table_05_decision_regions_with_ci.csv|Table 3 Test decision regions with Wilson intervals for fraud rate|action,claims,coverage_share,fraud_cases,fraud_rate,fraud_rate_ci_low,fraud_rate_ci_high,npv_if_approved}}

## 4.2 Capacity cost and policy ablation
At fixed capacities of 5%, 10%, 20%, and 30%, the system captured 24.3%, 40.5%, 63.2%, and 77.8% of labelled fraud. Investigation precision declined from 29.0% at 5% capacity to 15.6% at 30%.

{{TABLE:table_09_fixed_capacity.csv|Table 4 Fraud capture and precision under fixed investigation capacity|investigation_capacity,claims_investigated,fraud_captured,fraud_capture_rate,investigation_precision,legitimate_claims_investigated}}

{{FIGURE:figure_03_operational_value.png|Figure 2 Capacity trade-offs and declared cost scenarios}}

Under the low, base, and high-loss assumptions, Low-cost: £78.63 per claim for three-way versus £114.33 for binary (-35.70); Base: £184.76 per claim for three-way versus £253.34 for binary (-68.58); High-loss: £411.43 per claim for three-way versus £582.88 for binary (-171.45). The policies referred the same 830 claims for investigation. Their cost difference arises only from the assumed treatment of the 469 intermediate-risk claims. Because defer recovery and all monetary inputs are declared rather than observed, the result illustrates the calculation and its assumptions rather than establishing a financial business case.

Calibration changed Brier score from 0.051 to 0.050. The complete three-way policy produced 84.8% coverage and 27.0% covered-case error. Adding the fairness audit does not mechanically change predictions. The audit changes the information available for oversight and the conditions for deployment.

{{TABLE:table_11_framework_ablations.csv|Table 5 Policy ablation results|configuration,calibrated,defer_enabled,fairness_audit_present,brier_score,coverage,covered_error_rate,approval_npv,investigation_precision}}

{{FIGURE:figure_04_coverage_risk.png|Figure 3 Confidence-margin coverage and covered-case error}}

## 4.3 Proxy sensitivity and fairness audit
Removing AgeOfPolicyHolder changed test PR-AUC from 0.256 to 0.246, an absolute reduction of approximately 0.0104 and a relative change of -4.0%. Brier score changed from 0.050 to 0.050, and approval-region NPV from 99.27% to 99.37%. The age-band investigation-rate gap changed from 16.3% to 17.8%, an absolute increase of approximately 1.5 percentage points and a relative change of 9.4%. Removing the proxy therefore did not reduce the observed age-band action gap in this experiment.

{{TABLE:table_03_age_proxy_sensitivity.csv|Table 6 Proxy feature sensitivity analysis|specification,feature_count,validation_pr_auc,test_pr_auc,test_roc_auc,test_brier,approval_npv,age_investigation_rate_gap}}

{{FIGURE:figure_02_age_proxy_sensitivity.png|Figure 4 Predictive and age-band sensitivity to removing AgeOfPolicyHolder}}

At the retained specification, the age-band investigation-rate gap was 16.3% with bootstrap interval 9.6%-30.7%. The corresponding investigation TPR gap was 34.4% with interval 27.6%-52.7%. The sex investigation-rate gap was 6.4% with interval 2.8%-10.9%. Wide intervals, particularly for fraud-conditional and intersectional measures, reflect small positive counts. These findings are monitoring signals, not evidence that a field caused disparity or that an individual decision was discriminatory.

{{TABLE:table_08a_fairness_main.csv|Table 7 Three action fairness audit by principal group|attribute,group,n,fraud_n,prevalence,approve,defer,investigate,TPR,FNR,approval_NPV}}

{{TABLE:table_08c_fairness_gap_main.csv|Table 8 Bootstrap intervals for between group gaps|attribute,metric,estimate,low,high}}

{{FIGURE:figure_05_three_action_fairness.png|Figure 5 Approval defer and investigation rates by audited group}}

Held-out permutation importance identified Fault (0.124), BasePolicy (0.099), AddressChange_Claim (0.050), Year (0.037), PolicyType (0.032), AgeOfPolicyHolder (0.032). AgeOfPolicyHolder was among the leading features, which motivated the proxy sensitivity analysis. Importance measures predictive dependence and can be shared across correlated variables; it is not a causal explanation.

{{TABLE:table_15_permutation_importance.csv|Table 9 Leading held-out permutation importance values|feature,importance_mean,importance_std}}

{{FIGURE:figure_07_permutation_importance.png|Figure 6 Global feature sensitivity measured by PR-AUC decrease after permutation}}

## 4.4 Threshold robustness and temporal shift
Sigmoid and isotonic calibration produced test Brier scores 0.050 and 0.050, respectively; sigmoid was retained. Across five random seeds, test PR-AUC averaged 0.255 (SD 0.011). Bootstrap intervals were 0.204-0.317 for PR-AUC and 0.680-0.806 for recall.

The approval-threshold bootstrap median was 0.049 with interval 0.031-0.070. The investigation-threshold median was 0.100 with interval 0.076-0.124. When those validation-bootstrap thresholds were applied to fixed test probabilities, approval NPV had median 99.17% and range 98.55%-99.46%; fraud capture had median 71.9% and range 56.8%-79.5%; investigation precision had median 17.6% and range 14.7%-19.7%; and defer coverage had median 17.7% and range 8.1%-26.6%. The ranges show that policy outcomes are sensitive to validation-sample threshold selection.

{{TABLE:table_07b_threshold_operational_stability.csv|Table 10 Operational propagation of validation bootstrap thresholds|metric,median,ci_2_5,ci_97_5,bootstrap_samples}}

The chronological 1994/1995/1996 experiment yielded test PR-AUC 0.158, ROC-AUC 0.771, Brier score 0.048, precision 0.105, and recall 0.803. Temporal PR-AUC was 0.098 lower than the primary random-split estimate, demonstrating sensitivity to evaluation period. The temporal result therefore indicates that random splits produced a more optimistic discrimination estimate; it does not support preferring random splits.

{{FIGURE:figure_06_uncertainty_robustness.png|Figure 7 Bootstrap uncertainty repeated seeds and chronological stress testing}}

# 5 Discussion
## 5.1 Contributions to literature
The study contributes to fraud analytics by separating model-family comparison from imbalance treatment and by evaluating decisions under explicit capacity. On this benchmark, HistGradientBoosting without balancing ranked first on the prespecified cross-validation criterion, but that result is local to the dataset and protocol. The relevant contribution is the comparison design, not a general claim that resampling is ineffective.

The study also reframes calibrated fraud screening as an information-system work-allocation artifact. The score does not replace the investigator. It assigns standard processing, requests additional evidence, or refers a claim for investigation under thresholds selected for approval safety and fraud capture. This makes the delegation arrangement visible, consistent with Baird and Maruping's (2021) account of task distribution and coordination between people and agentic artifacts. It also avoids assuming that any nominal human-in-the-loop arrangement is effective; Fügener et al. (2022) show that the direction and quality of delegation matter.

The fairness contribution is similarly sociotechnical. Direct protected fields were separated from scoring, the retained age-derived proxy was tested, group outcomes were reported across all three actions, and gap uncertainty was quantified. This corresponds to the representation, learning, and calibration layers identified by Rai, Tian, and Xue (2026). The results also support Teodorescu et al.'s (2021) warning that fairness cannot be reduced to a one-time automated correction. Removing AgeOfPolicyHolder reduced PR-AUC and increased the observed age-band investigation gap, demonstrating that a technically simple omission does not guarantee a fairer allocation.

## 5.2 Design propositions
The evaluated artifact supports four bounded propositions. They are design implications from one historical benchmark and prototype, not universal causal laws.

**DP1 Comparable learning choices:** An auditable AI triage system should compare model families under a common imbalance treatment before testing class weighting or resampling separately. This makes performance differences attributable to identifiable design choices and reduces leakage risk.

**DP2 Calibrated capacity constrained allocation:** A triage system should translate calibrated probabilities into actions through thresholds tied to approval safety and investigative capacity, and should report how threshold instability changes operational outcomes. A single discrimination metric is insufficient for governing work allocation.

**DP3 Explicit human deferral:** An intermediate-risk region should be represented as a distinct request for evidence or professional review, with defined responsibilities and appeal routes. It should not be described as predictive uncertainty unless the system directly estimates and validates uncertainty.

**DP4 Adaptive fairness governance:** Fairness controls should span data representation, model learning, calibrated action thresholds, subgroup outcome monitoring, and periodic revalidation. Proxy removal and action-rate parity should be treated as diagnostic interventions rather than proof of fairness.

These propositions extend the artifact from an applied model toward design knowledge in the sense described by Hevner et al. (2004) and Gregor and Hevner (2013). Their scope is deliberately limited by the study's data and evaluation conditions.

## 5.3 Practical implications
For an insurer, the first implementation decision is investigator capacity, not an abstract classification threshold. The capacity table shows the expected trade-off between fraud capture and legitimate claims reviewed. A local cost matrix can then include investigator labour, claimant burden, missed-fraud exposure, delay, appeal, and recovery. The current GBP scenarios only demonstrate the calculation because no insurer supplied those values.

The defer region requires an operating procedure. It should state what additional evidence is requested, who reviews it, the service deadline, how the claimant contests the outcome, and when a case advances to investigation. Explanations should let reviewers interrogate the score and compare it with claim evidence. They should not be treated as proof of fraud, intent, or causality.

Deployment also requires a lawful basis for protected-attribute auditing, role-based access, logging, model approval, override recording, and periodic review. Monitoring should include prevalence, calibration, approval NPV, investigation precision, defer volume, threshold stability, and group-conditional action and error rates. Human reviewers need training to recognise the limits of model explanations and the possibility of automation bias.

## 5.4 Robustness fairness and governance implications
The temporal PR-AUC of 0.158 was substantially below the random-split estimate of 0.256. Random-split performance is therefore an optimistic internal estimate for this historical source. A contemporary external validation is required before operational use.

Threshold ranges were also operationally consequential. Across validation bootstraps, the approval-region NPV range crossed below the 0.99 validation target on the fixed test set, and investigation coverage, fraud capture, precision, and defer volume varied materially. An organisation should therefore approve a threshold policy together with tolerance bands, minimum sample requirements, escalation rules, and capacity contingencies rather than treating a single fitted cut-point as permanent.

Fairness gaps must be interpreted with prevalence and uncertainty. TPR and FNR compare fraud-conditional behaviour, while action-rate gaps describe allocation burden. Neither class of metric settles legal or normative fairness. Their joint use provides evidence for review, and wide intervals identify where more data are needed.

# 6 Limitations
The benchmark covers 1994-1996 and may not represent current reporting channels, vehicles, claimant behaviour, fraud tactics, or investigation practices. Labels may reproduce historical selection and verification processes. The study has no contemporary external insurer test, prospective intervention, actual claim-severity amounts, investigator-time observations, claimant-delay costs, appeals, or reversal outcomes.

The cost matrix is illustrative. The 25% residual cost assigned to deferred fraud is a scenario parameter rather than a measured recovery rate. Thresholds were selected on one validation partition and remain organisation-specific. The threshold-propagation ranges hold test predictions fixed and therefore isolate threshold-selection instability; they do not include test-population uncertainty. Some intersectional groups contain few fraud cases, making conditional rates imprecise. The temporal split uses only three historical years.

The study evaluates a prototype artifact but does not include field observation of investigator use, claimant experience, organisational adoption, or governance effectiveness. The design propositions therefore require testing in contemporary settings. Fairness auditing is descriptive and cannot determine legal compliance. The system must not autonomously deny a claim, accuse a claimant, infer deception from voice, or treat image damage classification as evidence of fraud.

# 7 Conclusion
This study evaluates a leakage-safe and reproducible information-system artifact for calibrated three-way motor-insurance fraud triage. RQ1 shows how calibrated risk, approval safety, and investigator capacity can define approval, defer, and investigation actions. RQ2 identifies controls for comparable model evaluation, proxy-sensitive fairness audit, threshold propagation, explanation, and temporal revalidation. The held-out PR-AUC was 0.256, while the temporal PR-AUC was 0.158, confirming that random-split evidence is insufficient for deployment. Removing AgeOfPolicyHolder reduced PR-AUC and did not reduce the age-band investigation gap. The artifact is not production-ready and does not make final claim decisions. Its contribution is a transparent allocation design and a set of bounded propositions that can be tested with contemporary claim-linked operational data.

# Declarations
**Ethics and privacy:** The experiments use a public historical benchmark and do not make live claim decisions.

**Funding:** No external funding was used, subject to author confirmation before submission.

**Competing interests:** The author declares no competing interests, subject to author confirmation before submission.

**Data availability:** The Fraud Oracle dataset is cited with its Figshare DOI. Redistribution and reuse remain subject to the source record's terms.

**Code availability:** Code, tests, analysis scripts, and the dashboard are available at https://github.com/tollyboy88/FairClaim-MM-Leakage-Safe-Fairness-Audited-Insurance-Fraud-Triage. A fixed release and archival DOI should be inserted after the author creates the release.

**AI assistance disclosure:** OpenAI Codex assisted code development, analysis checking, and language drafting. The human author is responsible for verifying the data, computations, citations, interpretation, and final submitted text.

{{REFERENCES}}
