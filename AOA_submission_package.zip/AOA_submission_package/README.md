# Applied Operations and Analytics revision package

## Paper identity

**Title:** Calibrated Three-Way Triage for Leakage-Safe and Fairness-Audited Motor Insurance Fraud Screening

**Target journal:** Applied Operations and Analytics

The paper evaluates structured claim data as a calibrated work-allocation system. The unlinked image experiment is excluded because the image records have no claim-level verified fraud outcomes.

## Evidence-bound revision map

| Reviewer concern | Implemented response |
|---|---|
| Incorrect percentage changes | Recomputed from unrounded outputs: PR-AUC decreased 4.04%; age-band investigation-rate gap increased 9.41% |
| Temporal interpretation | Treats the 1994/1995/1996 PR-AUC of 0.158 as evidence that the random split is optimistic |
| Overstated selective-prediction claim | Uses “three-way triage” and defines defer as an operational intermediate-risk region, not direct uncertainty |
| Threshold stability | Propagates 500 validation-bootstrap threshold pairs into fixed-test approval NPV, fraud capture, precision, and defer coverage |
| Conditional fairness errors | Reports group TPR/FNR and bootstrap intervals for between-group action and error-rate gaps |
| Unequal policy comparator | Uses the same investigation threshold and the same 830 investigated test claims for binary and three-way cost scenarios |
| Information Systems contribution | Uses two broader research questions, relevant IS literature, four bounded design propositions, and separate contribution/practice subsections |
| Reproducibility | Supplies the executed notebook, scripts, figures, tables, clean manuscript, highlighted manuscript, and response letter |

## Reproduce

Obtain `fraud_oracle.csv` from the Figshare record cited in the manuscript and place it in the package root, subject to that record's reuse terms. Then run:

```powershell
python -m pip install -r requirements.txt
python scripts\run_aoa_revision_analyses.py
python scripts\finalize_aoa_outputs.py
python scripts\render_manuscript_equations.py
python scripts\build_aoa_revision_notebook.py
python scripts\build_aoa_submission_docx.py
```

## Scientific boundaries

- Cost inputs and the 25% residual deferred-fraud cost are declared sensitivity assumptions, not observed insurer values or realised savings.
- Temporal testing is an internal historical stress test, not contemporary external validation.
- Group gaps are descriptive monitoring signals and do not establish causation, discrimination, or legal compliance.
- The system is a research prototype. It does not make autonomous approval, denial, or fraud findings.
- Before submission, the author must confirm funding, competing interests, originality, exclusive consideration, affiliation, email, ORCID, dataset terms, and the AI-assistance disclosure.
