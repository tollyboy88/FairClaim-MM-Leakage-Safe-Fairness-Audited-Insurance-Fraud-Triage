# References — US Harvard author–date style

Barocas, S., Hardt, M., and Narayanan, A. (2023) ‘Fairness and Machine Learning: Limitations and Opportunities’, Cambridge, MA: MIT Press. Available at: https://fairmlbook.org/

Barry, L. and Charpentier, A. (2022) ‘The fairness of machine learning in insurance: New rags for an old man?’, arXiv preprint arXiv:2205.08112. Available at: https://arxiv.org/abs/2205.08112

Bolton, R.J. and Hand, D.J. (2002) ‘Statistical fraud detection: A review’, Statistical Science, 17(3), pp. 235–255. https://doi.org/10.1214/ss/1042727940

Brier, G.W. (1950) ‘Verification of forecasts expressed in terms of probability’, Monthly Weather Review, 78(1), pp. 1–3. https://doi.org/10.1175/1520-0493(1950)078<0001:VOFEIP>2.0.CO;2

Chawla, N.V., Bowyer, K.W., Hall, L.O., and Kegelmeyer, W.P. (2002) ‘SMOTE: Synthetic Minority Over-sampling Technique’, Journal of Artificial Intelligence Research, 16, pp. 321–357. https://doi.org/10.1613/jair.953

Chouldechova, A. (2017) ‘Fair prediction with disparate impact: A study of bias in recidivism prediction instruments’, Big Data, 5(2), pp. 153–163. https://doi.org/10.1089/big.2016.0047

Côté, O., Côté, M.P., and Charpentier, A. (2025) ‘A fair price to pay: Exploiting causal graphs for fairness in insurance’, Journal of Risk and Insurance, 92, pp. 33–75. https://doi.org/10.1111/jori.12503

Davis, J. and Goadrich, M. (2006) ‘The relationship between Precision-Recall and ROC curves’, in Proceedings of the 23rd International Conference on Machine Learning, pp. 233–240. https://doi.org/10.1145/1143844.1143874

El-Yaniv, R. and Wiener, Y. (2010) ‘On the foundations of noise-free selective classification’, Journal of Machine Learning Research, 11(53), pp. 1605–1641. Available at: https://jmlr.org/papers/v11/el-yaniv10a.html

Fisher, A., Rudin, C., and Dominici, F. (2019) ‘All models are wrong, but many are useful: Learning a variable's importance by studying an entire class of prediction models simultaneously’, Journal of Machine Learning Research, 20(177), pp. 1–81. Available at: https://jmlr.org/papers/v20/18-760.html

Geifman, Y. and El-Yaniv, R. (2019) ‘SelectiveNet: A deep neural network with an integrated reject option’, in Proceedings of the 36th International Conference on Machine Learning, pp. 2151–2159. Available at: https://proceedings.mlr.press/v97/geifman19a.html

Guo, C., Pleiss, G., Sun, Y., and Weinberger, K.Q. (2017) ‘On calibration of modern neural networks’, in Proceedings of the 34th International Conference on Machine Learning, pp. 1321–1330. Available at: https://proceedings.mlr.press/v70/guo17a.html

Hardt, M., Price, E., and Srebro, N. (2016) ‘Equality of opportunity in supervised learning’, in Advances in Neural Information Processing Systems 29. Available at: https://proceedings.neurips.cc/paper/2016/hash/6a9659feb1216f14f7384ba499518b38-Abstract.html

Harjai, S., Khatri, S.K., and Singh, G. (2019) ‘Detecting fraudulent insurance claims using random forests and SMOTE’, in 2019 4th International Conference on Information Systems and Computer Networks, pp. 123–128. https://doi.org/10.1109/ISCON47742.2019.9036162

He, H. and Garcia, E.A. (2009) ‘Learning from imbalanced data’, IEEE Transactions on Knowledge and Data Engineering, 21(9), pp. 1263–1284. https://doi.org/10.1109/TKDE.2008.239

Ibrahim, M. (2024) ‘fraud_oracle.csv’, figshare. https://doi.org/10.6084/m9.figshare.24994233

Information Commissioner's Office and The Alan Turing Institute (2020) ‘Explaining decisions made with AI’, Online resource. Available at: https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/artificial-intelligence/explaining-decisions-made-with-artificial-intelligence/

Itri, B., Mohamed, Y., Omar, B., and Mohamed, Q. (2019) ‘Performance comparative study of machine learning algorithms for automobile insurance fraud detection’, in 2019 International Conference on Intelligent Computing in Data Sciences. https://doi.org/10.1109/ICDS47004.2019.8942277

Kleinberg, J., Mullainathan, S., and Raghavan, M. (2017) ‘Inherent trade-offs in the fair determination of risk scores’, in 8th Innovations in Theoretical Computer Science Conference, pp. 43:1–43:23. https://doi.org/10.4230/LIPIcs.ITCS.2017.43

Komsrimorakot, P. and Siriborvornratanakul, T. (2025) ‘Enhancing fraud detection in imbalanced motor insurance datasets using CP-SMOTE and Random Under-Sampling’, Journal of Big Data, 12, pp. 172. https://doi.org/10.1186/s40537-025-01217-3

Lindholm, M., Richman, R., Tsanakas, A., and Wuthrich, M.V. (2024) ‘What is fair? Proxy discrimination vs. demographic disparities in insurance pricing’, Scandinavian Actuarial Journal. https://doi.org/10.1080/03461238.2024.2364741

Lundberg, S.M. and Lee, S.I. (2017) ‘A unified approach to interpreting model predictions’, in Advances in Neural Information Processing Systems 30. Available at: https://papers.nips.cc/paper/2017/hash/8a20a8621978632d76c43dfd28b67767-Abstract.html

Muranda, C., Ali, A., and Shongwe, T. (2020) ‘Detecting fraudulent motor insurance claims using support vector machines with adaptive synthetic sampling method’, in 2020 61st International Scientific Conference on Information Technology and Management Science. https://doi.org/10.1109/ITMS51158.2020.9259322

Muranda, C., Ali, A., and Shongwe, T. (2021) ‘Deep learning method for detecting fraudulent motor insurance claims using unbalanced data’, in 2021 62nd International Scientific Conference on Information Technology and Management Science. https://doi.org/10.1109/ITMS52826.2021.9615264

Ngai, E.W.T., Hu, Y., Wong, Y.H., Chen, Y., and Sun, X. (2011) ‘The application of data mining techniques in financial fraud detection: A classification framework and an academic review of literature’, Decision Support Systems, 50(3), pp. 559–569. https://doi.org/10.1016/j.dss.2010.08.006

Niculescu-Mizil, A. and Caruana, R. (2005) ‘Predicting good probabilities with supervised learning’, in Proceedings of the 22nd International Conference on Machine Learning, pp. 625–632. https://doi.org/10.1145/1102351.1102430

Ozaltin, O. and Karadag Erdemir, O. (2025) ‘Detecting automobile insurance fraud using a novel penalty-driven feature selection method with particle swarm optimization and machine learning classifiers’, Scientific Reports, 15, pp. 41793. https://doi.org/10.1038/s41598-025-25700-2

Phua, C., Lee, V., Smith, K., and Gayler, R. (2010) ‘A comprehensive survey of data mining-based fraud detection research’, arXiv preprint arXiv:1009.6119. Available at: https://arxiv.org/abs/1009.6119

Pugnana, A. and Ruggieri, S. (2023) ‘AUC-based selective classification’, in Proceedings of the 26th International Conference on Artificial Intelligence and Statistics, pp. 2494–2514. Available at: https://proceedings.mlr.press/v206/pugnana23a.html

Ribeiro, M.T., Singh, S., and Guestrin, C. (2016) ‘Why should I trust you? Explaining the predictions of any classifier’, in Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining, pp. 1135–1144. https://doi.org/10.1145/2939672.2939778

Saito, T. and Rehmsmeier, M. (2015) ‘The precision-recall plot is more informative than the ROC plot when evaluating binary classifiers on imbalanced datasets’, PLOS ONE, 10(3), pp. e0118432. https://doi.org/10.1371/journal.pone.0118432

Schrijver, G., Sarmah, D.K., and El-Hajj, M. (2024) ‘Automobile insurance fraud detection using data mining: A systematic literature review’, Intelligent Systems with Applications, 21, pp. 200340. https://doi.org/10.1016/j.iswa.2024.200340

Shi, H., Tayebi, M.A., Pei, J., and Cao, J. (2023) ‘Cost-sensitive learning for medical insurance fraud detection with temporal information’, IEEE Transactions on Knowledge and Data Engineering, 35(10), pp. 10451–10463. https://doi.org/10.1109/TKDE.2023.3240431

Subudhi, S. and Panigrahi, S. (2018) ‘Effect of class imbalanceness in detecting automobile insurance fraud’, in 2018 International Conference on Data Science and Business Analytics, pp. 528–531. https://doi.org/10.1109/ICDSBA.2018.00104

West, J. and Bhattacharya, M. (2016) ‘Intelligent financial fraud detection: A comprehensive review’, Computers & Security, 57, pp. 47–66. https://doi.org/10.1016/j.cose.2015.09.005
