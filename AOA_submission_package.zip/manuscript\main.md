# Abstract
Motor-insurance fraud screening is an imbalanced allocation problem in which missed fraud, unnecessary investigation, and delayed legitimate payment have different operational consequences. This study develops a leakage-safe, calibrated selective-prediction framework that assigns claims to approval, abstention, or investigation. Using 15,420 public claims with 5.99% labelled fraud, six model families were compared without hidden balancing; five imbalance treatments were then evaluated separately for the selected family. HistGradientBoosting without balancing achieved the highest mean cross-validated precision–recall area under the curve (PR-AUC) and was nearly tied on fixed validation, while sigmoid calibration produced a held-out PR-AUC of 0.256 (95% bootstrap CI 0.204–0.317) and Brier score 0.050. At 10% investigation capacity, 40.5% of labelled fraud was captured with 24.3% investigation precision. Removing AgeOfPolicyHolder changed test PR-AUC from 0.256 to 0.246 and changed the age-group investigation-rate gap from 16.3% to 17.8%. A train-1994/test-1996 stress test yielded PR-AUC 0.158, showing the limits of random-split evidence. Across declared low, base, and high-loss scenarios, the three-way policy produced lower illustrative expected cost than a binary policy; these are sensitivity results, not realised savings. The contribution is an auditable operational framework that joins consistent comparison, capacity-constrained triage, abstention, uncertainty, proxy-feature sensitivity, action-level fairness, and explainability without claiming autonomous claim adjudication.

**Keywords:** insurance fraud; operations analytics; selective prediction; probability calibration; algorithmic fairness; class imbalance; investigation capacity; explainable artificial intelligence

# 1. Introduction
Insurance fraud detection is commonly treated as rare-event classification, but an insurer does not purchase a ranking metric: it allocates limited investigative attention while trying to avoid missed fraud, unnecessary scrutiny, and delayed legitimate settlement. Reviews by Bolton and Hand (2002), Phua et al. (2010), Ngai et al. (2011), and West and Bhattacharya (2016) establish the statistical and data-mining foundations of fraud detection. The recent motor-insurance review by Schrijver et al. (2024) nevertheless finds that public datasets remain scarce and structured supervised learning still dominates the literature.

Much applied work responds to imbalance through resampling or classifier-specific weighting. Examples include Subudhi and Panigrahi (2018), Harjai et al. (2019), Itri et al. (2019), Muranda et al. (2020; 2021), Komsrimorakot and Siriborvornratanakul (2025), and Ozaltin and Karadag Erdemir (2025). These studies advance prediction, but the operational claim can become unclear when model families use different implicit imbalance treatments or when resampling is not isolated inside training folds. SMOTE is an influential method (Chawla et al., 2002), yet imbalance remedies should be treated as empirical alternatives rather than automatic requirements (He and Garcia, 2009).

Three further gaps matter for operational deployment. First, probability quality is separate from ranking quality: the Brier score evaluates probabilistic accuracy (Brier, 1950), and post-hoc calibration can materially change threshold interpretation (Niculescu-Mizil and Caruana, 2005; Guo et al., 2017). Second, binary classification hides uncertainty. Selective classification instead permits a reject or defer region (El-Yaniv and Wiener, 2010; Geifman and El-Yaniv, 2019; Pugnana and Ruggieri, 2023). Third, deleting sensitive variables does not guarantee fairness because other fields can encode proxies, group base rates can differ, and formal fairness criteria can conflict (Hardt et al., 2016; Chouldechova, 2017; Kleinberg et al., 2017).

This paper therefore frames fraud screening as a reproducible operations-analytics problem with four research questions:

1. **RQ1:** Under a leakage-safe and methodologically consistent protocol, which model family and imbalance strategy provides the strongest validation PR-AUC?
2. **RQ2:** How much labelled fraud is captured at fixed investigation capacities, and how does calibrated three-way triage compare with binary triage under declared cost scenarios and selective-prediction ablations?
3. **RQ3:** How does removal of the retained age-derived proxy AgeOfPolicyHolder affect discrimination, calibration, approval safety, and age-group investigation disparity; and what disparities remain across approval, abstention, and investigation?
4. **RQ4:** How stable are performance and thresholds under bootstrap resampling, alternative calibration, repeated random seeds, and a chronological train/validation/test stress test?

The paper deliberately excludes the earlier image experiment from its main claim. The available image records are not linked at claim level to the fraud labels, so their damage classification performance cannot establish fraud-prediction validity. The revised contribution is selective operational triage, not multimodal fraud detection.

# 2. Related work and research gap
Precision–recall evaluation is especially informative when the positive class is rare (Davis and Goadrich, 2006; Saito and Rehmsmeier, 2015). However, a higher PR-AUC does not by itself specify how many claims can be investigated, what happens to uncertain cases, or whether a nominal risk score behaves as a probability. Cost-sensitive fraud research demonstrates the value of linking temporal evidence and asymmetric losses to modelling decisions (Shi et al., 2023), but public motor-insurance studies rarely report capacity curves, abstention, calibration, and declared cost sensitivity together.

Insurance fairness is also domain-specific. Barry and Charpentier (2022) distinguish social and actuarial conceptions of fairness. Lindholm et al. (2024) show why proxy discrimination and demographic disparity should not be conflated, while Côté et al. (2025) illustrate the value of causal reasoning in insurance fairness. General treatments further caution that fairness metrics encode normative choices rather than offering a universal certificate (Barocas et al., 2023). The present study therefore reports observed group outcomes and uncertainty, not a legal conclusion or a claim that removal of protected fields makes a system fair.

Explainability has similar limits. Local surrogates (Ribeiro et al., 2016) and additive attribution methods (Lundberg and Lee, 2017) are widely used, but correlated features can destabilise model-reliance interpretations (Fisher et al., 2019). The project uses held-out permutation importance as a global sensitivity measure and reference-replacement deltas for individual dashboard records. Both are presented as predictive associations. This follows the Information Commissioner’s Office and Alan Turing Institute (2020) emphasis on rationale, data, fairness, safety/performance, and impact explanations.

The research gap is consequently an integrated and reproducible decision-support evaluation: consistent model comparison; separately controlled imbalance experiments; calibrated abstention; fixed-capacity and cost sensitivity; proxy-feature analysis; all-action fairness; uncertainty; temporal stress testing; and non-causal explanation.

# 3. Materials and methods
## 3.1 Data, outcome, and leakage controls
The Fraud Oracle benchmark contains 15,420 motor claims, of which 923 are labelled fraudulent (5.99%). The persistent dataset record is provided by Ibrahim (2024). The records cover 1994–1996. For the primary experiment, a stratified 60/20/20 split created training, validation, and untouched test partitions. PolicyNumber was removed as an identifier. Sex, Age, and MaritalStatus were withheld from scoring and retained for post-hoc audit. AgeOfPolicyHolder was initially retained because it is a categorical policyholder-age feature, then removed in the proxy sensitivity experiment.

Numeric missing values were median-imputed and standardised; categorical values were most-frequent-imputed and one-hot encoded. Every learned preprocessing operation and every resampling operation was fitted within the relevant training fold. Validation data selected the model, calibration method, and decision thresholds. The test set was not used for those selections.

## 3.2 Consistent model-family and imbalance experiments
Six model families were first compared with no class weighting or resampling: a prior-probability dummy classifier, logistic regression, Gaussian naïve Bayes, random forest, Extra Trees, and HistGradientBoosting. Mean five-fold stratified training PR-AUC was the primary family-selection criterion, with PR-AUC on the fixed validation partition used as a confirmation check.

The selected family was then evaluated under no balancing, balanced class weights, random oversampling, random undersampling, and SMOTENC. Sampling, where applicable, occurred inside training folds. This two-stage design prevents model-family rankings from being confounded with different imbalance remedies. PR-AUC is the primary metric; ROC-AUC and Brier score are secondary metrics. For precision P and recall R, the F2 score is:

$$F_2=\frac{5PR}{4P+R},\qquad P=\frac{TP}{TP+FP},\qquad R=\frac{TP}{TP+FN}.$$

{{TABLE:table_01_model_family_no_balancing.csv|Table 1. Consistent model-family comparison without balancing.|model,imbalance_treatment,cv_pr_auc_mean,cv_pr_auc_sd,validation_pr_auc,validation_brier}}

{{TABLE:table_02_hgb_imbalance_strategies.csv|Table 2. Imbalance strategies evaluated separately for HistGradientBoosting.|imbalance_strategy,cv_pr_auc_mean,cv_pr_auc_sd,validation_pr_auc,validation_brier,resampling_scope}}

{{FIGURE:figure_01_consistent_model_comparison.png|Figure 1. Validation PR-AUC for the consistent model-family and imbalance-strategy experiments.}}

## 3.3 Calibration and three-action decision rule
Five stratified training folds each fit a HistGradientBoosting estimator. A held-out sigmoid calibrator maps raw score z_k(x) to calibrated fraud probability p_k(x), and the ensemble mean is the operational score:

$$p_k(x)=\frac{1}{1+\exp\{a_k z_k(x)+b_k\}},\qquad \hat p(x)=\frac{1}{5}\sum_{k=1}^{5}p_k(x).$$

Here the subscript k indexes the fold member; the space between a_k and z_k(x) denotes multiplication. The positive sign in the denominator follows the sigmoid calibrator’s fitted parameterisation. Sigmoid and isotonic calibration were compared, with validation Brier score determining the retained method and test Brier score reported only after selection.

The investigation threshold tau_I maximised validation F2. The approval threshold tau_A was the largest lower threshold satisfying validation negative predictive value (NPV) of at least 0.99:

$$\operatorname{NPV}=\frac{TN}{TN+FN},\qquad d(x)=\begin{cases}\text{approve},&\hat p(x)<\tau_A,\\ \text{abstain},&\tau_A\leq\hat p(x)<\tau_I,\\ \text{investigate},&\hat p(x)\geq\tau_I.\end{cases}$$

The fitted thresholds were frozen before test evaluation. Abstention is a request for evidence or human review; investigation is a referral signal, not an accusation; approval means normal processing, not an irreversible automatic payment decision.

## 3.4 Operational capacity and declared cost scenarios
Claims were ranked by calibrated risk. The top 5%, 10%, 20%, and 30% were treated as fixed investigator-capacity budgets. At capacity q, fraud capture is the fraction of all labelled fraud within the highest-risk qN claims, while investigation precision is the fraud fraction among those reviewed.

Three declared GBP scenarios were used: low cost (£100 investigation, £50 additional legitimate-claim burden, £5,000 missed fraud, £40 abstention delay); base (£250, £150, £10,000, £100); and high loss (£500, £300, £25,000, £250). If N_I is the number investigated, N_I0 legitimate investigations, N_A1 approved fraud, N_U1 abstained fraud, and N_U0 legitimate abstentions, total scenario cost is:

$$C=c_I N_I+c_L N_{I0}+c_F(N_{A1}+\rho N_{U1})+c_D N_{U0},\qquad \rho=0.25.$$

The factor rho assumes that manual review recovers 75% of the missed-fraud consequence among abstained fraud cases. This is a transparent sensitivity parameter, not an empirical estimate. The study reports comparative scenario cost and never labels it realised savings.

## 3.5 Proxy-feature sensitivity, fairness, and explanation
The primary feature set retains AgeOfPolicyHolder while excluding the direct Age audit field. A second complete calibration-and-threshold pipeline removes AgeOfPolicyHolder. The two specifications are compared on validation/test PR-AUC, ROC-AUC, Brier score, approval-region NPV, thresholds, and the maximum minus minimum age-band investigation rate.

For Sex, AgeBand, MaritalStatus, and Sex-by-AgeBand intersections, the audit reports group prevalence, approval rate, abstention rate, investigation rate, fraud missed in the approval region, approval-region NPV, mean score, and expected calibration error. Wilson 95% intervals accompany binomial action and approval-safety rates. Sparse groups are not interpreted as stable evidence. These descriptive audits complement, rather than solve, the incompatibilities identified by Hardt et al. (2016), Chouldechova (2017), and Kleinberg et al. (2017).

Global explanation is the held-out PR-AUC reduction after feature j is permuted:

$$I_j=\operatorname{PR\!-\!AUC}(f,X,y)-\operatorname{PR\!-\!AUC}(f,X_{\pi(j)},y).$$

The dashboard’s local explanation replaces one feature at a time with a documented reference value and reports the probability change. Neither method identifies a causal effect or justifies adverse action by itself.

## 3.6 Ablations, uncertainty, and temporal stress test
Five configurations were evaluated: uncalibrated binary prediction; calibrated binary prediction; uncalibrated selective prediction; calibrated selective prediction without a fairness-audit component; and the complete framework. Coverage is the non-abstained share, and selective error risk is the classification error among covered cases.

One thousand non-parametric bootstrap samples estimated 95% intervals for PR-AUC, ROC-AUC, Brier score, precision, recall, and F2. Five hundred validation bootstraps assessed threshold stability. The complete experiment was repeated under five split seeds. A chronological stress test trained on 1994, selected thresholds on 1995, and tested on 1996, with Year removed from predictors. This is a temporal robustness check within one historical source, not external validation.

# 4. Results
## 4.1 RQ1: model and imbalance strategy
HistGradientBoosting ranked first without balancing on the prespecified family-selection criterion, with mean five-fold training PR-AUC 0.251 (SD 0.030) and validation PR-AUC 0.244. Random forest had lower mean cross-validated PR-AUC (0.241) but a fixed-validation PR-AUC only 0.000064 higher. In the separate imbalance experiment, no balancing ranked first with validation PR-AUC 0.244. The result supports HistGradientBoosting with no balancing for this benchmark; it does not generalise to a claim that balancing is always ineffective.

## 4.2 RQ2: selective triage, capacity, and operating cost
The sigmoid-calibrated model achieved test PR-AUC 0.256 (95% bootstrap CI 0.204–0.317), ROC-AUC 0.843, Brier score 0.050, precision 0.166, and recall 0.746. The approval threshold was 0.046961 and the investigation threshold was 0.092956. The three regions contained 1,785, 469, and 830 claims, with observed fraud rates 0.7%, 7.2%, and 16.6%, respectively. The approval-region NPV was 99.27%.

{{TABLE:table_05_decision_regions_with_ci.csv|Table 3. Test decision regions with Wilson 95% confidence intervals for observed fraud rate.|action,claims,coverage_share,fraud_cases,fraud_rate,fraud_rate_ci_low,fraud_rate_ci_high,npv_if_approved}}

At fixed capacities of 5%, 10%, 20%, and 30%, the system captured 24.3%, 40.5%, 63.2%, and 77.8% of labelled fraud. Investigation precision declined from 29.0% at 5% capacity to 15.6% at 30%, making the investigator-volume trade-off explicit.

{{TABLE:table_09_fixed_capacity.csv|Table 4. Fraud capture and precision under fixed investigation capacity.|investigation_capacity,claims_investigated,fraud_captured,fraud_capture_rate,investigation_precision,legitimate_claims_investigated}}

{{FIGURE:figure_03_operational_value.png|Figure 2. Operational trade-offs under fixed capacity and declared cost scenarios.}}

Under the low, base, and high-loss assumptions, Low-cost: £78.63 per claim for three-way versus £114.33 for binary (-35.70); Base: £184.76 per claim for three-way versus £253.34 for binary (-68.58); High-loss: £411.43 per claim for three-way versus £582.88 for binary (-171.45). Because the inputs are declared rather than observed, the result establishes threshold sensitivity and a calculation method, not a financial business case.

The ablation showed that calibration changed Brier score from 0.051 to 0.050. Selective prediction produced coverage 84.8% and selective error risk 27.0%. Adding the fairness audit does not mechanically change predictions, so the “calibrated selective, no fairness audit” and complete framework have identical predictive metrics; the audit changes governance visibility and required review, not the score.

{{TABLE:table_11_framework_ablations.csv|Table 5. Framework ablation results.|configuration,calibrated,abstention_enabled,fairness_audit_present,brier_score,coverage,selective_error_risk,approval_npv,investigation_precision}}

{{FIGURE:figure_04_coverage_risk.png|Figure 3. Selective error risk across retained prediction coverage.}}

## 4.3 RQ3: age proxy, all-action fairness, and explanation
Removing AgeOfPolicyHolder changed test PR-AUC from 0.256 to 0.246, Brier score from 0.050 to 0.050, and approval-region NPV from 99.27% to 99.37%. The maximum age-band investigation-rate gap changed from 16.3% to 17.8%. Removal exposed a measurable performance–disparity trade-off that requires governance judgement.

{{TABLE:table_03_age_proxy_sensitivity.csv|Table 6. Proxy-feature sensitivity analysis.|specification,feature_count,validation_pr_auc,test_pr_auc,test_roc_auc,test_brier,approval_npv,age_investigation_rate_gap}}

{{FIGURE:figure_02_age_proxy_sensitivity.png|Figure 4. Predictive and age-group disparity sensitivity to removal of AgeOfPolicyHolder.}}

Across all three actions, the largest observed investigation-rate gap was 21.2% for Sex_x_AgeBand; the largest approval-rate gap was 18.8%, and the largest abstention-rate gap was 17.9%. Approval-region missed-fraud counts and NPVs varied by group, with wide intervals where fraud-positive or approved counts were small. These are monitoring signals, not evidence that a particular field caused disparity or that any individual outcome was discriminatory.

{{TABLE:table_08_three_action_fairness.csv|Table 7. Three-action fairness audit by group; full machine-readable table includes Wilson intervals.|attribute,group,n,fraud_prevalence,approval_rate,abstention_rate,investigation_rate,fraud_missed_in_approval_n,approval_region_npv,expected_calibration_error}}

{{FIGURE:figure_05_three_action_fairness.png|Figure 5. Approval, abstention, and investigation rates by audited group.}}

Held-out permutation importance identified Fault (0.124), BasePolicy (0.099), AddressChange_Claim (0.050), Year (0.037), PolicyType (0.032), AgeOfPolicyHolder (0.032). The retained age-derived proxy was therefore not hidden: its model reliance motivated the explicit sensitivity analysis. Importance measures predictive dependence and can be shared across correlated variables; it is not a causal explanation.

{{TABLE:table_15_permutation_importance.csv|Table 8. Leading held-out permutation importance values.|feature,importance_mean,importance_std}}

{{FIGURE:figure_07_permutation_importance.png|Figure 6. Global held-out feature sensitivity measured by PR-AUC decrease after permutation.}}

## 4.4 RQ4: calibration, uncertainty, seed stability, and temporal shift
Sigmoid and isotonic calibration produced test Brier scores 0.050 and 0.050, respectively; sigmoid was retained. Across five random seeds, test PR-AUC averaged 0.255 (SD 0.011). Bootstrap 95% intervals were 0.204–0.317 for PR-AUC and 0.680–0.806 for recall. The approval threshold bootstrap median was 0.049 with interval 0.031–0.070, while the investigation threshold median was 0.100 with interval 0.076–0.124.

The chronological 1994/1995/1996 experiment yielded test PR-AUC 0.158, ROC-AUC 0.771, Brier score 0.048, precision 0.105, and recall 0.803. Temporal PR-AUC was 0.098 lower than the primary random-split estimate, demonstrating sensitivity to evaluation period.

{{FIGURE:figure_06_uncertainty_robustness.png|Figure 7. Bootstrap metric uncertainty, repeated-seed results, and chronological stress-test performance.}}

# 5. Discussion
The answer to RQ1 is not that class balancing is generally unnecessary. It is that, under one controlled benchmark protocol, HistGradientBoosting without balancing provided the strongest mean cross-validated PR-AUC and was effectively tied with random forest on fixed validation, while alternative imbalance remedies did not improve the selected family’s validation PR-AUC. This is a defensible negative result because model-family and imbalance experiments were separated and sampling did not cross fold boundaries.

RQ2 changes the evaluation unit from a binary prediction to operational allocation. Capacity curves show what proportion of known fraud enters review when resources cover a fixed share of claims. The three-way rule also makes uncertainty visible. The declared-cost calculation can be populated with an insurer’s governed estimates for investigator labour, claimant burden, missed fraud, delay, and abstention recovery. Until those values are supplied and prospectively validated, the reported GBP figures must remain sensitivity scenarios.

RQ3 shows why stating that “age was removed” would have been inaccurate. The direct Age field was audit-only, but AgeOfPolicyHolder remained predictive. Removing it provides a transparent proxy audit: test PR-AUC changed from 0.256 to 0.246, while the age investigation-rate gap changed from 16.3% to 17.8%. More generally, protected-field exclusion did not eliminate differences in approval, abstention, investigation, calibration, or approval safety. This is consistent with insurance-fairness scholarship (Barry and Charpentier, 2022; Lindholm et al., 2024; Côté et al., 2025). A deployer would need lawful data governance, human appeal, subgroup outcome monitoring, and prospective testing of any mitigation.

RQ4 qualifies the random-split headline. Bootstrap and repeated-seed analyses quantify sampling variation, calibration comparison tests probability mapping, and the chronological experiment probes historical shift. The temporal PR-AUC was 0.158 versus the random-split estimate of 0.256, so the operational policy should be revalidated by period. Because all years arise from the same old dataset, even a successful temporal test would not establish contemporary insurer validity.

The explainability component is intentionally conservative. Permutation sensitivity identifies model reliance at dataset level; reference replacement can show what changed an individual score relative to a documented baseline. Neither establishes causation, intent, or fraud. Explanations should support trained human review and contestability rather than automate adverse adjudication.

# 6. Limitations
The main limitation is data age: the benchmark covers 1994–1996 and may not represent current reporting channels, vehicles, claimant behaviour, fraud tactics, or investigation practices. Labels may reproduce historical selection and verification processes. The study has no contemporary external insurer test, prospective intervention, actual claim-severity amounts, investigator-time observations, claimant-delay costs, appeals, or reversal outcomes.

The cost matrix is illustrative. The 25% residual cost assigned to abstained fraud is a scenario parameter, not a measured recovery rate. Thresholds were chosen on one validation partition and remain organisation-specific. Bootstrap intervals quantify sampling uncertainty but do not capture dataset shift or label error. Some intersectional groups are small, making action and missed-fraud rates imprecise. The temporal split uses only three historical years.

Fairness auditing is descriptive and cannot determine legal compliance. Protected variables require a lawful and governed audit basis. Permutation importance can be distorted by correlated features, while reference replacement can create implausible combinations. The system must not autonomously deny a claim, accuse a claimant, infer deception from voice, or treat image damage classification as proof of fraud.

# 7. Operational and governance implications
Before real use, an insurer should collect a contemporary, consented, de-identified, and claim-linked dataset containing structured claim fields, evidence timestamps, assessor actions, confirmed outcomes, appeal and reversal outcomes, investigation effort, delays, and actual cost consequences. A data-protection impact assessment, security review, human-factors study, model approval process, and documented override and appeal routes are prerequisites.

Thresholds should be selected against investigator capacity and a locally approved cost matrix. Monitoring should report prevalence, calibration, coverage, approval NPV, investigation precision, and approval/abstention/investigation rates by governed audit group. Retraining or threshold revision should be triggered by drift rules, not ad hoc pressure to increase detections. The dashboard stores prototype decisions locally and separates the model score from the final human adjudication.

# 8. Conclusion
This study contributes a leakage-safe and reproducible framework for calibrated selective motor-insurance fraud triage. RQ1 selected HistGradientBoosting with no balancing. RQ2 quantified fraud capture from 24.3% at 5% capacity to 77.8% at 30% capacity and found lower illustrative expected cost for three-way triage under the declared scenarios. RQ3 showed that removing AgeOfPolicyHolder changed PR-AUC from 0.256 to 0.246, while subgroup differences remained across all actions. RQ4 found mean repeated-seed PR-AUC 0.255 and temporal PR-AUC 0.158, making uncertainty and period shift explicit. The work does not claim production readiness or autonomous fraud determination. Its value is a transparent operational method: compare models consistently, test imbalance remedies rather than assume them, calibrate before thresholding, expose an abstention region, quantify capacity and declared costs, audit proxy features and all three actions, communicate uncertainty, and preserve human accountability.

# Declarations
**Ethics and privacy:** The experiments use a public historical benchmark and do not make live claim decisions.

**Funding:** No external funding was used, subject to author confirmation before submission.

**Competing interests:** The author declares no competing interests, subject to author confirmation before submission.

**Data availability:** The Fraud Oracle dataset is cited with its Figshare DOI. Redistribution and reuse remain subject to the source record’s terms.

**Code availability:** Code, tests, analysis scripts, and the dashboard are available at https://github.com/tollyboy88/FairClaim-MM-Leakage-Safe-Fairness-Audited-Insurance-Fraud-Triage. A fixed release and archival DOI should be inserted after the author creates the release.

**AI-assistance disclosure:** OpenAI Codex/GPT-assisted tools supported code development, analysis checking, and language drafting in July 2026. The human author is responsible for verifying the data, computations, citations, interpretation, and final submitted text.

{{REFERENCES}}
