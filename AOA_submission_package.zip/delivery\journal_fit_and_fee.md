# Applied Operations and Analytics submission record

Verified 29 July 2026.

## Why this journal

Applied Operations and Analytics is a fully open-access journal published by
Taylor & Francis on behalf of The Operational Research Society. Its scope
emphasises operational decision-making, information processing, business
applications, replicable analytical methods, real-world applicability, and
negative or null findings. These priorities fit this paper's central
contributions:

- investigation-capacity allocation;
- expected-cost sensitivity;
- calibrated selective prediction;
- leakage-safe comparison of imbalance strategies;
- action-level fairness auditing; and
- reproducible decision-support software.

Official journal page:
https://www.tandfonline.com/journals/taoa20/about-this-journal

## Publication charge

The journal's official page currently states: "Taylor & Francis is currently
covering the cost of publication charges for this journal." This is the basis
for selecting the journal as the zero-cost open-access target.

The same page also contains Taylor & Francis's generic open-access wording
about APCs. The specific cost-covering notice appears above that generic
section. Because offers can change, the author must capture a dated screenshot
and obtain written confirmation from the journal or submission system
immediately before submission. Do not submit if the system displays a charge
that has not been explicitly waived or covered.

## Indexing and maturity

The journal began publishing in 2025 and is listed in DOAJ. It is a new journal
and does not yet have the indexing history or citation metrics of long-established
operations-research journals. This is the trade-off for the currently covered
open-access publication route.

